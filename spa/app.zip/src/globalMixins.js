import { TASK_STATUSES } from './constants';

export const globalMixins = {
    data: function() {
        return {
            TASK_STATUSES
        };
    }
};